from flask import Flask, render_template, request
from pymongo import *
from app import app_flask

#Hace falta realizar la logica de obtener los datos del formulario
#y permitir el acceso a index desde login, también la de registro.
#En general, hace falta toda la logica de analisis de datos y la
#parte de la base de datos.

#Conexión a MongoDB usando PyMongo
client = MongoClient()
db = client.redparATI_db

@app_flask.route('/')
def login():
    return render_template("login.html")

@app_flask.route('/login', methods=['POST'])
def login_after_register():
	usuario = request.form['usuario_reg']
	nombre = request.form['nombre_reg']
	correo = request.form['correo_reg']
	password = request.form['password_reg']

	db.Usuario.insert_one( { "user_name": usuario, "password": password, "email": correo, "nombre": nombre, "descripcion": null, "color": null, "libro": null, "musica": null, "video_juego": null, "lenguajes": null, "genero": null, "ci": null, "fecha_nacimiento": null, "ruta_foto_perfil": null, "telefono": null, "facebook": null, "twitter": null, "activa": null } )

	return render_template("login.html")

@app_flask.route('/index')
def index():
	return render_template("index.html")