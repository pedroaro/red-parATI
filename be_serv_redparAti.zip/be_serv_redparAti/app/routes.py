from flask import render_template
from app import app_flask

#Hace falta realizar la logica de obtener los datos del formulario
#y permitir el acceso a index desde login, también la de registro.
#En general, hace falta toda la logica de analisis de datos y la
#parte de la base de datos.

@app_flask.route('/')
def login():
    return render_template("login.html")


@app_flask.route('/index')
def index():
	return render_template("index.html")